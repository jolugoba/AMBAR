<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class propietarioModelo extends mainModel{


protected function agregar_propietario_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO propietario (id,PropietarioDNI,PropietarioNombre,PropietarioApellido,PropietarioTelefono,PropietarioOcupacion,PropietarioDireccion,CuentaCodigo,id_apartamento) VALUES(null,:DNI,:Nombre,:Apellido,:Telefono,:Ocupacion,:Direccion,:Codigo,:Apartamento)");
 

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Apellido",$datos['Apellido']);
$sql->bindParam(":Telefono",$datos['Telefono']);
$sql->bindParam(":Ocupacion",$datos['Ocupacion']);
$sql->bindParam(":Direccion",$datos['Direccion']);
$sql->bindParam(":Codigo",$datos['Codigo']);
$sql->bindParam(":Apartamento",$datos['Apartamento']);
$sql->execute();

return $sql;
}

protected function eliminar_propietario_modelo($codigo){
	$query=mainModel::conectar()->prepare("DELETE FROM propietario WHERE CuentaCodigo=:Codigo");
	$query->bindParam(":Codigo",$codigo);
	$query->execute();
	return $query;
	
}

protected function datos_propietario_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM propietario WHERE CuentaCodigo=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id  FROM propietario");
	}
	$query->execute();
	return $query;
}




protected function datos_apartamento_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM apartamentos WHERE id_apartamento=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id_apartamento  FROM apartamentos");
	}
	$query->execute();
	return $query;
}

protected function datos_respuesta_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM novedades WHERE id_novedades=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id_novedades  FROM novedades");
	}
	$query->execute();
	return $query;
}




protected function actualizar_propietario_modelo($datos){
$query=mainModel::conectar()->prepare("UPDATE propietario SET PropietarioDNI=:DNI,PropietarioNombre=:Nombre,PropietarioApellido=:Apellido,PropietarioTelefono=:Telefono,PropietarioOcupacion=:Ocupacion,PropietarioDireccion=:Direccion,id_apartamento=:Apartamento WHERE CuentaCodigo=:Codigo");
$query->bindParam(":DNI",$datos['DNI']);
$query->bindParam(":Nombre",$datos['Nombre']);
$query->bindParam(":Apellido",$datos['Apellido']);
$query->bindParam(":Telefono",$datos['Telefono']);
$query->bindParam(":Ocupacion",$datos['Ocupacion']);
$query->bindParam(":Direccion",$datos['Direccion']);
$query->bindParam(":Codigo",$datos['Codigo']);
$query->bindParam(":Apartamento",$datos['Apartamento']);
$query->execute();
	return $query;
}








protected function actualizar_apartamento_modelo($datos){
$query=mainModel::conectar()->prepare("UPDATE apartamentos SET torre=:DNI,numero=:Nombre,area=:Apellido,parqueadero=:Telefono WHERE id_apartamento=:Codigo");
$query->bindParam(":Codigo",$datos['Codigo']);
$query->bindParam(":DNI",$datos['DNI']);
$query->bindParam(":Nombre",$datos['Nombre']);
$query->bindParam(":Apellido",$datos['Apellido']);
$query->bindParam(":Telefono",$datos['Telefono']);

$query->execute();
	return $query;
}



protected function actualizar_respuesta_modelo($datos){







$query=mainModel::conectar()->prepare("UPDATE respuestas SET asunto_respuestas=:Apellido,descripcion_respuestas=:Telefono WHERE id_respuestas=:Apellido");

$query->bindParam(":Apellido",$datos['Apellido']);
$query->bindParam(":Telefono",$datos['Telefono']);
$query->bindParam(":Direccion",$datos['Direccion']);

$query->execute();
	return $query;
}



protected function agregar_respuesta_modelo($datos){



	
$sql=mainModel::conectar()->prepare ("INSERT INTO respuestas (id_respuestas,asunto_respuestas,descripcion_respuestas,fecha_respuestas,hora_respuestas,year_respuestas,id_novedades) VALUES(null,:Nombre,:Apellido,:Fecha,:HoraInicio,:Year,:DNI)");
 
		

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Apellido",$datos['Apellido']);
$sql->bindParam(":Telefono",$datos['Telefono']);
$sql->bindParam(":Fecha",$datos['Fecha']);
$sql->bindParam(":HoraInicio",$datos['HoraInicio']);
$sql->bindParam(":Year",$datos['Year']);



		

$sql->execute();

return $sql;
}




}