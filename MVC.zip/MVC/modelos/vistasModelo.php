<?php
class vistasModelo{
	protected function obtener_vistas_modelo($vistas){
	$listaBlanca=["actualizar","apartamentos","apartamento","cartelera","crearUsuario","eventos","eventoslist","myevento","myeventop","informes","informeslist","myinformes","myinformesp","novedades","novedadeslist","noticias","noticiaslist","mynoticia","mynoticiap","reservar","salones","admin","catalogo","adminlist","adminsearch","apartamentomod","home","mydata","mydatap","mydataa","myaccount","myaccountp","myaccounta","myinforme","myinformep","myrespuesta","myrespuestap","respuesta","respuestalist","prop","propsearch","proplist","usuarios"];
	if(in_array($vistas, $listaBlanca)){
		if(is_file("./vistas/contenidos/".$vistas."-view.php")){
			$contenido="./vistas/contenidos/".$vistas."-view.php";
		}else{
			$contenido="login";
		}
	}elseif($vistas=="login"){
	$contenido="login";
	}elseif($vistas=="index"){
	$contenido="login";
	}else{
		$contenido="404";
	}
	return $contenido;
	}
}