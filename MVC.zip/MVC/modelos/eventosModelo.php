<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class eventosModelo extends mainModel{


protected function agregar_eventos_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO eventos (id_eventos,asunto_eventos,descripcion_eventos,fecha_eventos,hora_eventos,year_eventos) VALUES(null,:DNI,:Nombre,:Fecha,:HoraInicio,:Year)");
 

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Fecha",$datos['Fecha']);
		$sql->bindParam(":HoraInicio",$datos['HoraInicio']);
		$sql->bindParam(":Year",$datos['Year']);


$sql->execute();

return $sql;
}


protected function datos_respuesta_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM eventos WHERE id_eventos=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id_eventos  FROM eventos");
	}
	$query->execute();
	return $query;
}


}