<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class noticiasModelo extends mainModel{


protected function agregar_noticias_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO noticias (id_noticias,asunto_noticias,descripcion_noticias,fecha_noticias,hora_noticias,year_noticias) VALUES(null,:DNI,:Nombre,:Fecha,:HoraInicio,:Year)");
 

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Fecha",$datos['Fecha']);
		$sql->bindParam(":HoraInicio",$datos['HoraInicio']);
		$sql->bindParam(":Year",$datos['Year']);


$sql->execute();

return $sql;
}


protected function datos_respuesta_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM noticias WHERE id_noticias=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id_noticias  FROM noticias");
	}
	$query->execute();
	return $query;
}


}