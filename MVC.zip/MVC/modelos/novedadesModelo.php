<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class novedadesModelo extends mainModel{


protected function agregar_novedades_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO novedades (id_novedades,asunto_novedades,descripcion_novedades,fecha_novedades,hora_novedades,year_novedades,CuentaCodigo,torre,numero,respuesta) VALUES(null,:DNI,:Nombre,:Fecha,:HoraInicio,:Year,:Codigo,:Torre,:Numero,:Respuesta)");
 

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Codigo",$datos['Codigo']);
$sql->bindParam(":Torre",$datos['Torre']);
$sql->bindParam(":Numero",$datos['Numero']);
$sql->bindParam(":Fecha",$datos['Fecha']);
		$sql->bindParam(":HoraInicio",$datos['HoraInicio']);
		$sql->bindParam(":Year",$datos['Year']);
		$sql->bindParam(":Respuesta",$datos['Respuesta']);

$sql->execute();

return $sql;
}



}