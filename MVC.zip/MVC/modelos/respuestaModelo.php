<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class respuestaModelo extends mainModel{

protected function agregar_respuesta_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO respuestas (id_respuestas,asunto_respuestas,descripcion_respuestas,fecha_respuestas,hora_respuestas,year_respuestas,id_novedades) VALUES(null,:Nombre,:Apellido,:Fecha,:HoraInicio,:Year,:DNI)");
 



$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Apellido",$datos['Apellido']);
$sql->bindParam(":Fecha",$datos['Fecha']);
		$sql->bindParam(":HoraInicio",$datos['HoraInicio']);
		$sql->bindParam(":Year",$datos['Year']);


$query=mainModel::conectar()->prepare("UPDATE novedades SET respuesta='Si' WHERE id_novedades=:DNI");
		$query->bindParam(":DNI",$datos['DNI']);
$query->execute();

$sql->execute();

return $sql;
}

protected function datos_respuesta_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM respuestas WHERE id_novedades=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id_respuestas  FROM respuestas");
	}
	$query->execute();
	return $query;
}





protected function actualizar_respuesta_modelo($datos){
$query=mainModel::conectar()->prepare("UPDATE respuestas SET asunto_respuestas=:Nombre,descripcion_respuestas=:Apellido,fecha_respuestas=:Fecha,hora_respuestas=:HoraInicio,year_respuestas=:Year WHERE id_respuestas=:DNI");

$query->bindParam(":DNI",$datos['DNI']);
$query->bindParam(":Nombre",$datos['Nombre']);
$query->bindParam(":Apellido",$datos['Apellido']);
$query->bindParam(":Fecha",$datos['Fecha']);
		$query->bindParam(":HoraInicio",$datos['HoraInicio']);
		$query->bindParam(":Year",$datos['Year']);


$query->execute();
	return $query;
}



}