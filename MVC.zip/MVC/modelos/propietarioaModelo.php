<?php 
if($peticionAjax){
require_once "../core/mainModel.php";
}else{
require_once "./core/mainModel.php";
}
class propietarioaModelo extends mainModel{


protected function agregar_propietarioa_modelo($datos){

	
$sql=mainModel::conectar()->prepare ("INSERT INTO apartamentos (id_apartamento,torre,numero,area,parqueadero) VALUES(null,:DNI,:Nombre,:Apellido,:Telefono)");
 

$sql->bindParam(":DNI",$datos['DNI']);
$sql->bindParam(":Nombre",$datos['Nombre']);
$sql->bindParam(":Apellido",$datos['Apellido']);
$sql->bindParam(":Telefono",$datos['Telefono']);


$sql->execute();

return $sql;
}

protected function eliminar_propietarioa_modelo($codigo){
	$query=mainModel::conectar()->prepare("DELETE FROM propietarioa WHERE CuentaCodigo=:Codigo");
	$query->bindParam(":Codigo",$codigo);
	$query->execute();
	return $query;
	
}

protected function datos_propietarioa_modelo($tipo,$codigo){
	if($tipo=="Unico"){
		$query=mainModel::conectar()->prepare("SELECT * FROM propietarioa WHERE CuentaCodigo=:Codigo");
		$query->bindParam(":Codigo",$codigo);
		
	}elseif($tipo=="Conteo"){
$query=mainModel::conectar()->prepare("SELECT id  FROM propietarioa");
	}
	$query->execute();
	return $query;
}

protected function actualizar_propietarioa_modelo($datos){
$query=mainModel::conectar()->prepare("UPDATE propietarioa SET PropietarioDNI=:DNI,PropietarioNombre=:Nombre,PropietarioApellido=:Apellido,PropietarioTelefono=:Telefono WHERE CuentaCodigo=:Codigo");
$query->bindParam(":DNI",$datos['DNI']);
$query->bindParam(":Nombre",$datos['Nombre']);
$query->bindParam(":Apellido",$datos['Apellido']);
$query->bindParam(":Telefono",$datos['Telefono']);
$query->bindParam(":Codigo",$datos['Codigo']);
$query->execute();
	return $query;
}

}