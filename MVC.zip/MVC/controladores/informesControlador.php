<?php 
if($peticionAjax){
require_once "../modelos/informesModelo.php";
}else{
require_once "./modelos/informesModelo.php";
}
class informesControlador extends informesModelo{


public function agregar_informes_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	

			$fechaActual=date("Y-m-d");
			$yearActual=date("Y");
			$horaActual=date("h:i:s a");

				
								$dataAD=[
						"DNI"=>$dni,
						"Nombre"=>$nombre,
						"Fecha"=>$fechaActual,
						"HoraInicio"=>$horaActual,
						"Year"=>$yearActual
						];
					$guardarPropietario=informesModelo::agregar_informes_modelo($dataAD);
					if($guardarPropietario->rowCount()==1){
	$alerta=[
	"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"El informe fue creado exitosamente",
		"Tipo"=>"success"
		];	
					}else{
						
							$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El informe no fue creado por favor contacte a su administrador",
		"Tipo"=>"error"
		];		
					}

				
				
	
	return mainModel::sweet_alert($alerta);
}
public function paginador_informes_controlador($pagina,$registros,$privilegio,$codigo){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();

			if($privilegio==1){
$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM informes ORDER BY id_informes ASC LIMIT $inicio,$registros
			");
			}
			else{

$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM informes  ORDER BY id_informes ASC LIMIT $inicio,$registros
			");
			}


		
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">ASUNTO</th>
                  <th class="text-center">FECHA</th>';

                  if($privilegio=='1' || $privilegio=='4' ){
                  	  	$tabla.='
				<th class="text-center">RESPONDIDO POR ADMINISTRADOR</th>
                  	';
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	 $tabla.='
                 <tr>
                  <td>'.$contador.'</td>
                  <td>'.$rows['asunto_informes'].'</td>
                  
                  <td>'.$rows['fecha_informes']."-".$rows['hora_informes'].'</td>';
                  
                  if($privilegio=='1'){

                  		$tabla.='
                  	 <td>Ver Informe
                    <a href="'.SERVERURL.'myinforme/user/'.mainModel::encryption($rows['id_informes']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                 

                  ';
              
}




                  	
                  

                    if($privilegio=='4'){

 		$tabla.='
                  	 <td>Ver Informe
                    <a href="'.SERVERURL.'myinformep/user/'.mainModel::encryption($rows['id_informes']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                 

                  ';
                  		


                  	
                  }
              
                  $tabla.='</tr>';
	$contador++;
 } 
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'informeslist/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'informeslist/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'informeslist/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'informeslist/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'informeslist/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}

public function datos_informes_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return informesModelo::datos_respuesta_modelo($tipo,$codigo);
}

	

}