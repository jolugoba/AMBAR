<?php 
if($peticionAjax){
require_once "../modelos/apartamentosModelo.php";
}else{
require_once "./modelos/apartamentosModelo.php";
}
class apartamentosControlador extends apartamentosModelo{


public function agregar_apartamentos_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	$apellido=mainModel::limpiar_cadena($_POST['apellido-reg']);
	$telefono=mainModel::limpiar_cadena($_POST['telefono-reg']);



		$foto="Male3Avatar.png";
		

	if($dni!=3){
		$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No tiene permiso para realizar esta acccion consulte a su administrador",
		"Tipo"=>"error"
		];
	}else{
		$consulta1=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE torre='$dni' AND numero='$nombre'");
		if($consulta1->rowCount()>=1){
			$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El apartamento y torre ingresado ya se encuentra",
		"Tipo"=>"error"
		];
		}else{
			if($email!=""){
$consulta2=mainModel::ejecutar_consulta_simple("SELECT numero FROM apartamentos WHERE numero='$nombre'");			
$ec=$consulta2->rowCount();
		}else{
			$ec=0;
			}
			




			if($ec>=1){
$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No tiene permiso para realizar esta acccion consulte a su administrador",
		"Tipo"=>"error"
		];
			}else{
				$consulta3=mainModel::ejecutar_consulta_simple("SELECT torre FROM apartamentos WHERE torre='$dni'");
				if($consulta3->rowCount()>=1){
					$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No tiene permiso para realizar esta acccion consulte a su administrador",
		"Tipo"=>"error"
		];				
			}else{
				
					$dataAD=[
						"DNI"=>$dni,
						"Nombre"=>$nombre,
						"Apellido"=>$apellido,
						"Telefono"=>$telefono						
					];
					$guardarPropietario=apartamentosModelo::agregar_apartamentos_modelo($dataAD);
					if($guardarPropietario->rowCount()==1){
	$alerta=[
	"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"El apartamento fue creado exitosamente",
		"Tipo"=>"success"
		];	
					}else{
						mainModel::eliminar_cuenta($codigo);
							$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No tiene permiso para realizar esta acccion consulte a su administrador",
		"Tipo"=>"error"
		];		
					}

			
				}
			}
		}
	}
	return mainModel::sweet_alert($alerta);
}


public function paginador_administrador_controlador($pagina,$registros,$privilegio,$codigo){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
	
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();
		 $datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM  apartamentos  GROUP BY apartamentos.torre ASC LIMIT $inicio,$registros
			");
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		<form method="POST" action="'.SERVERURL.'apartamento/0">
    
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
               
                  <th class="text-center">LISTADO DE TORRES</th>';
                  if($privilegio<='2'){
                  	
                  }
                  if($privilegio=='1'){
                  	  	
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	$torreres=$rows['torre'];
	 $tabla.='
                 <tr>
             
                    
                 <td>   <input type="submit"  name="post" value="'.$torreres.'"> </td>';

                  if($privilegio<='2'){
                  	$tabla.='
                  	 
                  

                  ';
                  }
                  if($privilegio=='1'){
                 
                  }
               
                  $tabla.='</tr>';
	$contador++;
}
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'apartamentos/'.$torre.'/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'apartamentos/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'apartamentos/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'apartamentos/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'apartamentos/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}

public function paginador_apartamento_controlador($pagina,$registros,$privilegio,$codigo,$post){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
		$post=mainModel::limpiar_cadena($post);
		
	
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();
		 $datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM  apartamentos WHERE torre='$post' ORDER BY apartamentos.numero ASC LIMIT $inicio,$registros
			");
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		
    
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
                  <th class="text-center"># de Apartamento</th>
                  <th class="text-center">Area</th>
                  <th class="text-center">Parqueadero</th>
                  <th class="text-center">Propietarios</th>
                  <th class="text-center">Informacion Personal</th>
                  <th class="text-center">Eliminar</th>';
                  if($privilegio<='2'){
                  	
                  }
                  if($privilegio=='1'){
                  	  	
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	 $tabla.='
                 <tr>
             
                  	 
                  
                    
                 <td>   <input type="submit"  name="'.$rows['numero'].'" value="Apartamento '.$rows['numero'].'"> </td>
                  <td>   <input type="submit"  name="'.$rows['area'].'" value="'.$rows['area'].'"> </td>
                   <td>   <input type="submit"  name="'.$rows['parqueadero'].'" value="'.$rows['parqueadero'].'"> </td>'
                  ;



                    if($privilegio<='2'){
                  	$tabla.='
                  	 <td>
                    <a href="'.SERVERURL.'myaccountp/user/'.mainModel::encryption($rows['id_apartamento']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                  <td>
                    <a href="'.SERVERURL.'mydataa/user/'.mainModel::encryption($rows['id_apartamento']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>

                  ';
                  }
                   if($privilegio=='1'){
                  	$tabla.='
                  	    <td>
                    <form action="'.SERVERURL.'ajax/apartamentosAjax.php" method="POST" data-form="delete" class="formulario" name="formulario_registro"  autocomplete="off" enctype="multipart/form-data"> 
                    <input type="hidden" name="codigo-del" value="'.($rows['id_apartamento']).'">
                    <input type="hidden" name="privilegio-admin" value="'.mainModel::encryption($privilegio).'">
                      <button type="submit" class="btn btn-danger btn-raised btn-xs">
                        <i class="zmdi zmdi-delete"></i>
                      </button>
                      <div class="RespuestaAjax"></div>
                    </form>
                  </td>
                  ';
                  }
                 
               
                  $tabla.='</tr>';
	$contador++;
}
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'apartamentos/'.$torre.'/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'apartamento/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'apartamento/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'apartamento/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'apartamento/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}
public function	eliminar_apartamentos_controlador(){
		$codigo=$_POST['codigo-del'];
		$adminPrivilegio=mainModel::decryption($_POST['privilegio-admin']);
		$codigo=mainModel::limpiar_cadena($codigo);
		$adminPrivilegio=mainModel::limpiar_cadena($adminPrivilegio);

		if($adminPrivilegio=='1'){
			$query1=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE id_apartamento='$codigo'");
		
			
	$DelAdmin=apartamentosModelo::eliminar_apartamentos_modelo($codigo);
	
	if($DelAdmin->rowCount()==1){
		$alerta=[
		"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"El apartamento fue eliminado exitosamente",
		"Tipo"=>"success"
		];	
	}else{
$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" No podemos eliminar este apartamento en este momento",
		"Tipo"=>"error"
		];	
	}

		

		}else{
			$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" NO TIENE ESTOS PRIVILEGIOS PARA REALIZAR ESTA OPERACION",
		"Tipo"=>"error"
		];	
		}
		return mainModel::sweet_alert($alerta);
	}


}