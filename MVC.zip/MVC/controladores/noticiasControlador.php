<?php 
if($peticionAjax){
require_once "../modelos/noticiasModelo.php";
}else{
require_once "./modelos/noticiasModelo.php";
}
class noticiasControlador extends noticiasModelo{


public function agregar_noticias_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	

			$fechaActual=date("Y-m-d");
			$yearActual=date("Y");
			$horaActual=date("h:i:s a");

				
								$dataAD=[
						"DNI"=>$dni,
						"Nombre"=>$nombre,
						"Fecha"=>$fechaActual,
						"HoraInicio"=>$horaActual,
						"Year"=>$yearActual
						];
					$guardarPropietario=noticiasModelo::agregar_noticias_modelo($dataAD);
					if($guardarPropietario->rowCount()==1){
	$alerta=[
	"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"La noticia fue agregada exitosamente",
		"Tipo"=>"success"
		];	
					}else{
						
							$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"La noticia no pudo ser agregada contacte a su administrador",
		"Tipo"=>"error"
		];		
					}

				
				
	
	return mainModel::sweet_alert($alerta);
}
public function paginador_noticias_controlador($pagina,$registros,$privilegio,$codigo){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();

			if($privilegio==1){
$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM noticias ORDER BY id_noticias ASC LIMIT $inicio,$registros
			");
			}
			else{

$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM noticias  ORDER BY id_noticias ASC LIMIT $inicio,$registros
			");
			}


		
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">ASUNTO</th>
                  <th class="text-center">FECHA</th>';

                  if($privilegio=='1' || $privilegio=='4' ){
                  	  	$tabla.='
				<th class="text-center">RESPONDIDO POR ADMINISTRADOR</th>
                  	';
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	 $tabla.='
                 <tr>
                  <td>'.$contador.'</td>
                  <td>'.$rows['asunto_noticias'].'</td>
                  
                  <td>'.$rows['fecha_noticias']."-".$rows['hora_noticias'].'</td>';
                  
                  if($privilegio=='1'){

                  		$tabla.='
                  	 <td>Ver Noticia
                    <a href="'.SERVERURL.'mynoticia/user/'.mainModel::encryption($rows['id_noticias']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                 

                  ';
              
}




                  	
                  

                    if($privilegio=='4'){

 		$tabla.='
                  	 <td>Ver Noticia
                    <a href="'.SERVERURL.'mynoticiap/user/'.mainModel::encryption($rows['id_noticias']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                 

                  ';
                  		


                  	
                  }
               
                  $tabla.='</tr>';
	$contador++;
}
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'proplist/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'noticiaslist/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'proplist/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'noticiaslist/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'noticiaslist/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}

public function datos_noticias_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return noticiasModelo::datos_respuesta_modelo($tipo,$codigo);
}

	

}