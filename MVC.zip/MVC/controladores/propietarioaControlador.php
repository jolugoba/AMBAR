<?php 
if($peticionAjax){
require_once "../modelos/propietarioaModelo.php";
}else{
require_once "./modelos/propietarioaModelo.php";
}
class propietarioaControlador extends propietarioaModelo{


public function agregar_propietarioa_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	$apellido=mainModel::limpiar_cadena($_POST['apellido-reg']);
	$telefono=mainModel::limpiar_cadena($_POST['telefono-reg']);


		

	
		$consulta1=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE torre='$dni' AND numero='$nombre'");
		if($consulta1->rowCount()>=1){
			$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El apartamento y torre  que ingreso ya se encuentran",
		"Tipo"=>"error"
		];
		}else{
			
					$dataAD=[
						"DNI"=>$dni,
						"Nombre"=>$nombre,
						"Apellido"=>$apellido,
						"Telefono"=>$telefono,
												
					];
					$guardarPropietario=propietarioaModelo::agregar_propietarioa_modelo($dataAD);
					if($guardarPropietario->rowCount()==1){
	$alerta=[
	"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"El apartamento fue creado exitosamnete",
		"Tipo"=>"success"
		];	
					}else{
						
							$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"Por favor contacte a su administrador",
		"Tipo"=>"error"
		];		
					}

				
				
	}
	return mainModel::sweet_alert($alerta);
}
public function paginador_propietarioa_controlador($pagina,$registros,$privilegio,$codigo){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();
		$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM propietarioa WHERE CuentaCodigo!='$codigo' AND id!='1' ORDER BY PropietarioNombre ASC LIMIT $inicio,$registros
			");
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">DNI</th>
                  <th class="text-center">NOMBRES</th>
                  <th class="text-center">APELLIDOS</th>
                  <th class="text-center">TELÉFONO</th>';
                  if($privilegio<='2'){
                  	$tabla.='
					<th class="text-center">A. CUENTA</th>
                  	<th class="text-center">A. DATOS</th>
                  	';
                  }
                  if($privilegio=='1'){
                  	  	$tabla.='
				<th class="text-center">ELIMINAR</th>
                  	';
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	 $tabla.='
                 <tr>
                  <td>'.$contador.'</td>
                  <td>'.$rows['PropietarioDNI'].'</td>
                  <td>'.$rows['PropietarioNombre'].'</td>
                  <td>'.$rows['PropietarioApellido'].'</td>
                  <td>'.$rows['PropietarioTelefono'].'</td>';
                  if($privilegio<='2'){
                  	$tabla.='
                  	 <td>
                    <a href="'.SERVERURL.'myaccountp/user/'.mainModel::encryption($rows['CuentaCodigo']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                  <td>
                    <a href="'.SERVERURL.'mydatap/user/'.mainModel::encryption($rows['CuentaCodigo']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>

                  ';
                  }
                  if($privilegio=='1'){
                  	$tabla.='
                  	   <td>
                    <form action="'.SERVERURL.'ajax/propietarioaAjax.php" method="POST" data-form="delete" class="formulario" name="formulario_registro"  autocomplete="off" enctype="multipart/form-data"> 
                    <input type="hidden" name="codigo-del" value="'.mainModel::encryption($rows['CuentaCodigo']).'">
                    <input type="hidden" name="privilegio-propietario" value="'.mainModel::encryption($privilegio).'">
                      <button type="submit" class="btn btn-danger btn-raised btn-xs">
                        <i class="zmdi zmdi-delete"></i>
                      </button>
                      <div class="RespuestaAjax"></div>
                    </form>
                  </td>
                  ';
                  }
               
                  $tabla.='</tr>';
	$contador++;
}
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'proplist/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'proplist/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'proplist/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'proplist/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'proplist/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}

	public function	eliminar_propietarioa_controlador(){
		$codigo=mainModel::decryption($_POST['codigo-del']);
		$propietarioPrivilegio=mainModel::decryption($_POST['privilegio-propietario']);
		$codigo=mainModel::limpiar_cadena($codigo);
		$propietarioPrivilegio=mainModel::limpiar_cadena($propietarioPrivilegio);

		if($propietarioPrivilegio=='1'){
			$query1=mainModel::ejecutar_consulta_simple("SELECT id FROM propietarioa WHERE CuentaCodigo='$codigo'");
			$datosPropietario=$query1->fetch();
			if($datosPropietario['id']!=1){
	$DelPropietario=propietarioaModelo::eliminar_propietarioa_modelo($codigo);
	mainModel::eliminar_bitacora($codigo);
	if($DelPropietario->rowCount()>=1){
		$DelCuenta=mainModel::eliminar_cuenta($codigo);

		if($DelCuenta->rowCount()==1){

$alerta=[
		"Alerta"=>"recargar",
		"Titulo"=>"Felicitaciones",
		"Texto"=>"El apartamento fue eliminado exitosamnete",
		"Tipo"=>"success"
		];	

		}else{
		$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No podemos eliminar este apartamento en este moemtno",
		"Tipo"=>"error"
		];	
		}

	}else{
$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No podemos eliminar este apartamento en este moemtno",
		"Tipo"=>"error"
		];	
	}

			}else{
		$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No podemos eliminar este apartamento en este moemtno",
		"Tipo"=>"error"
		];	
			}

		}else{
			$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" NO TIENE ESTOS PRIVILEGIOS PARA REALIZAR ESTA OPERACION",
		"Tipo"=>"error"
		];	
		}
		return mainModel::sweet_alert($alerta);
	}


public function datos_propietarioa_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return propietarioaModelo::datos_propietarioa_modelo($tipo,$codigo);
}

public function actualizar_propietarioa_controlador(){
$cuenta=mainModel::decryption($_POST['cuenta-up']);
$dni=mainModel::limpiar_cadena($_POST['dni-up']);
$nombre=mainModel::limpiar_cadena($_POST['nombre-up']);
$apellido=mainModel::limpiar_cadena($_POST['apellido-up']);
$telefono=mainModel::limpiar_cadena($_POST['telefono-up']);


$query1=mainModel::ejecutar_consulta_simple("SELECT * FROM propietarioa WHERE CuentaCodigo='$cuenta'");
$DatosPropietario=$query1->fetch();

if($dni!=$DatosPropietario['PropietarioDNI']){
	$consulta1=mainModel::ejecutar_consulta_simple("SELECT PropietarioDNI FROM propietarioa WHERE PropietarioDNI='$dni'");
	if($consulta1->rowCount()>=1){
				$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El apartamento y torre que ingreso ya se encuentran",
		"Tipo"=>"error"
		];	
		return mainModel::sweet_alert($alerta);
		exit();

	}

}
$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono,
	"Direccion"=>$especialidad,
	"Codigo"=>$cuenta
];
if(propietarioaModelo::actualizar_propietarioa_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
		$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
return mainModel::sweet_alert($alerta);
}

}