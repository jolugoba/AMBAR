<?php 
if($peticionAjax){
require_once "../modelos/propietarioModelo.php";
}else{
require_once "./modelos/propietarioModelo.php";
}
class propietarioControlador extends propietarioModelo{


public function agregar_propietario_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	$apellido=mainModel::limpiar_cadena($_POST['apellido-reg']);
	$telefono=mainModel::limpiar_cadena($_POST['telefono-reg']);
	$ocupacion=mainModel::limpiar_cadena($_POST['ocupacion-reg']);
	$especialidad=mainModel::limpiar_cadena($_POST['especialidad-reg']);
	$usuario=mainModel::limpiar_cadena($_POST['usuario-reg']);
	$password1=mainModel::limpiar_cadena($_POST['password1-reg']);
	$password2=mainModel::limpiar_cadena($_POST['password2-reg']);
	$email=mainModel::limpiar_cadena($_POST['email-reg']);
	$genero=mainModel::limpiar_cadena($_POST['optionsGenero']);
	$privilegio=mainModel::limpiar_cadena($_POST['optionsPrivilegio']);


		$foto="Male3Avatar.png";
		

	if($password1!=$password2){
		$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"Las contraseñas que ingreso no coinciden",
		"Tipo"=>"error"
		];
	}else{
		$consulta1=mainModel::ejecutar_consulta_simple("SELECT PropietarioDNI FROM propietario WHERE PropietarioDNI='$dni'");
		if($consulta1->rowCount()>=1){
			$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"La cedula que ingreso ya se encuentra",
		"Tipo"=>"error"
		];
		}else{
			if($email!=""){
$consulta2=mainModel::ejecutar_consulta_simple("SELECT CuentaEmail FROM cuenta WHERE CuentaEmail='$email'");			
$ec=$consulta2->rowCount();
		}else{
			$ec=0;
			}
			




			if($ec>=1){
$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El Email que ingreso ya se encuentra",
		"Tipo"=>"error"
		];
			}else{
				$consulta3=mainModel::ejecutar_consulta_simple("SELECT CuentaUsuario FROM cuenta WHERE CuentaUsuario='$usuario'");
				if($consulta3->rowCount()>=1){
					$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El usuario que ingreso aya se encuentra",
		"Tipo"=>"error"
		];				
			}else{
				$consulta4=mainModel::ejecutar_consulta_simple("SELECT id FROM cuenta");
				$numero=($consulta4->rowCount())+1;
				$codigo=mainModel::generar_codigo_aleatorio("PC",7,"$numero");
				$clave=mainModel::encryption($password1);
				
				$dataAC=[
					"Codigo"=>$codigo,
					"Privilegio"=>4,
					"Usuario"=>$usuario,
					"Clave"=>$clave,
					"Email"=>$email,
					"Estado"=>"Activo",
					"Tipo"=>"Propietario",
					"Genero"=>$genero,
					"Foto"=>$foto
				];
				$guardarCuenta=mainModel::agregar_cuenta($dataAC);
				if($guardarCuenta->rowCount()>=1){








					$query4=mainModel::ejecutar_consulta_simple("SELECT * FROM apartamentos WHERE torre='$ocupacion' AND numero='$especialidad'");
$DatosApartameto=$query4->fetch();

$consulta6=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE torre='$ocupacion' AND numero='$especialidad'");

if($consulta6->rowCount()>=1){

$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono,
	"Ocupacion"=>$ocupacion,
	"Direccion"=>$especialidad,
	"Codigo"=>$codigo,
	"Apartamento"=>$DatosApartameto['id_apartamento']
];
if(propietarioModelo::agregar_propietario_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
	
		$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
}
else{
	mainModel::eliminar_cuenta($codigo);
	$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El numero de apartamento ingresado no existe",
		"Tipo"=>"error"
		];	
}









				}else{
								$alerta=[
	"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido registrar el Propietario",
		"Tipo"=>"error"
		];		
				}









				}
			}
		}
	}
	return mainModel::sweet_alert($alerta);
}
public function paginador_propietario_controlador($pagina,$registros,$privilegio,$codigo){
		$pagina=mainModel::limpiar_cadena($pagina);
		$registros=mainModel::limpiar_cadena($registros);
		$privilegio=mainModel::limpiar_cadena($privilegio);
		$codigo=mainModel::limpiar_cadena($codigo);
		$tabla="";
		$pagina= (isset($pagina) && $pagina>0) ? (int) $pagina : 1;
		$inicio= ($pagina>0) ? (($pagina*$registros)-$registros) : 0;
		$conexion = mainModel::conectar();
		$datos = $conexion->query("
				SELECT SQL_CALC_FOUND_ROWS * FROM propietario WHERE CuentaCodigo!='$codigo' AND id!='1' ORDER BY PropietarioNombre ASC LIMIT $inicio,$registros
			");
		$datos= $datos->fetchAll();
		$total= $conexion->query("SELECT FOUND_ROWS()");
		$total= (int) $total->fetchColumn();
		$Npaginas= ceil($total/$registros);
		$tabla.='
		<div class="table-responsive">
            <table class="table table-hover text-center">
              <thead>
                <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">DNI</th>
                  <th class="text-center">NOMBRES</th>
                  <th class="text-center">APELLIDOS</th>
                  <th class="text-center">TELÉFONO</th>';
                  if($privilegio<='2'){
                  	$tabla.='
					<th class="text-center">A. CUENTA</th>
                  	<th class="text-center">A. DATOS</th>
                  	';
                  }
                  if($privilegio=='1'){
                  	  	$tabla.='
				<th class="text-center">ELIMINAR</th>
                  	';
                  }
                  
                    $tabla.='</tr>
              </thead>
              <tbody>
              ';
if($total>=1 && $pagina<=$Npaginas){
$contador=$inicio+1;
foreach ($datos as $rows) {
	 $tabla.='
                 <tr>
                  <td>'.$contador.'</td>
                  <td>'.$rows['PropietarioDNI'].'</td>
                  <td>'.$rows['PropietarioNombre'].'</td>
                  <td>'.$rows['PropietarioApellido'].'</td>
                  <td>'.$rows['PropietarioTelefono'].'</td>';
                  if($privilegio<='2'){
                  	$tabla.='
                  	 <td>
                    <a href="'.SERVERURL.'myaccountp/user/'.mainModel::encryption($rows['CuentaCodigo']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>
                  <td>
                    <a href="'.SERVERURL.'mydatap/user/'.mainModel::encryption($rows['CuentaCodigo']).'" class="btn btn-success btn-raised btn-xs">
                      <i class="zmdi zmdi-refresh"></i>
                    </a>
                  </td>

                  ';
                  }
                  if($privilegio=='1'){
                  	$tabla.='
                  	   <td>
                    <form action="'.SERVERURL.'ajax/propietarioAjax.php" method="POST" data-form="delete" class="formulario" name="formulario_registro"  autocomplete="off" enctype="multipart/form-data"> 
                    <input type="hidden" name="codigo-del" value="'.mainModel::encryption($rows['CuentaCodigo']).'">
                    <input type="hidden" name="privilegio-propietario" value="'.mainModel::encryption($privilegio).'">
                      <button type="submit" class="btn btn-danger btn-raised btn-xs">
                        <i class="zmdi zmdi-delete"></i>
                      </button>
                      <div class="RespuestaAjax"></div>
                    </form>
                  </td>
                  ';
                  }
               
                  $tabla.='</tr>';
	$contador++;
}
}else{
	if($total>='1'){
 $tabla.='
 <tr>
<td colspan"5">
<a href="'.SERVERURL.'proplist/" class="btn btn-sm btn-info btn-raised">
haga clic aca para recargar
</a>
</td>
</tr>
 ';
	}else{

	}
 $tabla.='
 <tr>
  <td colspan="5"> No hay registros en el sistema</td>
 </tr>
 ';
}

              $tabla.='</tbody></table></div>';

 	if($total>=1 && $pagina<=$Npaginas){
	$tabla.='
	          <nav class="text-center">
            <ul class="pagination pagination-sm">
	';


	if($pagina=='1'){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-left"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'proplist/'.($pagina-1).'/"><i class="zmdi zmdi-arrow-left"></i></a></li>';

	}


for ($i=0; $i<=$Npaginas ; $i++) { 
	if($Npaginas==$i){
		$tabla.='<li class="active"><a href="'.SERVERURL.'proplist/'.$i.'/">'.$i.'</a></li>';
	}else{
	$tabla.='<li><a href="'.SERVERURL.'proplist/'.$i.'/">'.$i.'</a></li>';
	}
}


	if($pagina==$Npaginas){
		$tabla.='<li class="disabled"><a><i class="zmdi zmdi-arrow-right"></i></a></li>';
	}else{
$tabla.='<li><a href="'.SERVERURL.'proplist/'.($pagina+1).'/"><i class="zmdi zmdi-arrow-right"></i></a></li>';

	}

	$tabla.='</ul></nav>';

	   		
 	}

		return $tabla;


	}

	public function	eliminar_propietario_controlador(){
		$codigo=mainModel::decryption($_POST['codigo-del']);
		$propietarioPrivilegio=mainModel::decryption($_POST['privilegio-propietario']);
		$codigo=mainModel::limpiar_cadena($codigo);
		$propietarioPrivilegio=mainModel::limpiar_cadena($propietarioPrivilegio);

		if($propietarioPrivilegio=='1'){
			$query1=mainModel::ejecutar_consulta_simple("SELECT id FROM propietario WHERE CuentaCodigo='$codigo'");
			$datosPropietario=$query1->fetch();
			if($datosPropietario['id']!=1){
	$DelPropietario=propietarioModelo::eliminar_propietario_modelo($codigo);
	mainModel::eliminar_bitacora($codigo);
	if($DelPropietario->rowCount()>=1){
		$DelCuenta=mainModel::eliminar_cuenta($codigo);

		if($DelCuenta->rowCount()==1){

$alerta=[
		"Alerta"=>"recargar",
		"Titulo"=>"Perfecto",
		"Texto"=>" La cuenta ha sido eliminada",
		"Tipo"=>"success"
		];	

		}else{
		$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No podemos eliminar esta ceuenta en este moemtno",
		"Tipo"=>"error"
		];	
		}

	}else{
$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" NO podemos eliminar este aministrador en este momento",
		"Tipo"=>"error"
		];	
	}

			}else{
		$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" NO puede eliminar el propietario principal",
		"Tipo"=>"error"
		];	
			}

		}else{
			$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>" NO TIENE ESTOS PRIVILEGIOS PARA REALIZAR ESTA OPERACION",
		"Tipo"=>"error"
		];	
		}
		return mainModel::sweet_alert($alerta);
	}


public function datos_propietario_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return propietarioModelo::datos_propietario_modelo($tipo,$codigo);
}

public function datos_apartamento_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return propietarioModelo::datos_apartamento_modelo($tipo,$codigo);
}


public function datos_respuesta_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return propietarioModelo::datos_respuesta_modelo($tipo,$codigo);
}



public function actualizar_propietario_controlador(){
$cuenta=mainModel::decryption($_POST['cuenta-up']);
$dni=mainModel::limpiar_cadena($_POST['dni-up']);
$nombre=mainModel::limpiar_cadena($_POST['nombre-up']);
$apellido=mainModel::limpiar_cadena($_POST['apellido-up']);
$telefono=mainModel::limpiar_cadena($_POST['telefono-up']);
$especialidad=mainModel::limpiar_cadena($_POST['especialidad-up']);

$query1=mainModel::ejecutar_consulta_simple("SELECT * FROM propietario WHERE CuentaCodigo='$cuenta'");
$DatosPropietario=$query1->fetch();

if($dni!=$DatosPropietario['PropietarioDNI']){
	$consulta1=mainModel::ejecutar_consulta_simple("SELECT PropietarioDNI FROM propietario WHERE PropietarioDNI='$dni'");
	if($consulta1->rowCount()>=1){
				$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El DNI que acaba de ingresar ya se encuentra registrado",
		"Tipo"=>"error"
		];	
		return mainModel::sweet_alert($alerta);
		exit();

	}

}
$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono,
	"Direccion"=>$especialidad,
	"Codigo"=>$cuenta
];
if(propietarioModelo::actualizar_propietario_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
		$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
return mainModel::sweet_alert($alerta);
}





public function actualizar_propietario_apartamento_controlador(){
$cuenta=mainModel::decryption($_POST['cuenta-up']);
$dni=mainModel::limpiar_cadena($_POST['dni-up']);
$nombre=mainModel::limpiar_cadena($_POST['nombre-up']);
$apellido=mainModel::limpiar_cadena($_POST['apellido-up']);
$telefono=mainModel::limpiar_cadena($_POST['telefono-up']);
$ocupacion=mainModel::limpiar_cadena($_POST['ocupacion-up']);
$especialidad=mainModel::limpiar_cadena($_POST['especialidad-up']);

$query1=mainModel::ejecutar_consulta_simple("SELECT * FROM propietario WHERE CuentaCodigo='$cuenta'");
$DatosPropietario=$query1->fetch();

if($dni!=$DatosPropietario['PropietarioDNI']){
	$consulta1=mainModel::ejecutar_consulta_simple("SELECT PropietarioDNI FROM propietario WHERE PropietarioDNI='$dni'");
	if($consulta1->rowCount()>=1){
				$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El DNI que acaba de ingresar ya se encuentra registrado",
		"Tipo"=>"error"
		];	
		return mainModel::sweet_alert($alerta);
		exit();

	}

}

$query2=mainModel::ejecutar_consulta_simple("SELECT * FROM apartamentos WHERE torre='$ocupacion' AND numero='$especialidad'");
$DatosApartameto=$query2->fetch();

$consulta2=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE torre='$ocupacion' AND numero='$especialidad'");

if($consulta2->rowCount()>=1){

$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono,
	"Ocupacion"=>$ocupacion,
	"Direccion"=>$especialidad,
	"Codigo"=>$cuenta,
	"Apartamento"=>$DatosApartameto['id_apartamento']
];

if(propietarioModelo::actualizar_propietario_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
		$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
}
else{
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El numero de apartamento ingresado no existe",
		"Tipo"=>"error"
		];	
}

return mainModel::sweet_alert($alerta);
}







public function actualizar_apartamento_controlador(){
$cuenta=mainModel::decryption($_POST['cuenta-upp']);
$dni=mainModel::limpiar_cadena($_POST['dni-up']);
$nombre=mainModel::limpiar_cadena($_POST['nombre-up']);
$apellido=mainModel::limpiar_cadena($_POST['apellido-up']);
$telefono=mainModel::limpiar_cadena($_POST['telefono-up']);


$query1=mainModel::ejecutar_consulta_simple("SELECT * FROM apartamentos WHERE id_apartamento='$cuenta'");
$DatosPropietario=$query1->fetch();

if($dni!=$DatosPropietario['torre'] && $nombre!=$DatosPropietario['numero']){
	$consulta1=mainModel::ejecutar_consulta_simple("SELECT id_apartamento FROM apartamentos WHERE torre='$dni' AND numero='$nombre'");
	if($consulta1->rowCount()>=1){
				$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El DNI que acaba de ingresar ya se encuentra registrado",
		"Tipo"=>"error"
		];	
		return mainModel::sweet_alert($alerta);
		exit();

	}

}
$dataAD=[
	"Codigo"=>$cuenta,
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono,
	"Cuenta"=>$telefono
];
if(propietarioModelo::actualizar_apartamento_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
		$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
return mainModel::sweet_alert($alerta);
}






public function agregar_respuesta_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	$apellido=mainModel::limpiar_cadena($_POST['apellido-reg']);
	$telefono=mainModel::limpiar_cadena($_POST['telefono-reg']);
	



		$consulta1=mainModel::ejecutar_consulta_simple("SELECT id_respuestas FROM respuestas WHERE id_novedades='$dni'");
		if($consulta1->rowCount()==0){



$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
	"Telefono"=>$telefono
	];
if(propietarioModelo::agregar_respuesta_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
	
		$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}		


}else{

			$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"El DNI que ingreso ya se encuentra",
		"Tipo"=>"error"
		];


		}
	
	return mainModel::sweet_alert($alerta);
}



}