<?php 
if($peticionAjax){
require_once "../modelos/respuestaModelo.php";
}else{
require_once "./modelos/respuestaModelo.php";
}
class respuestaControlador extends respuestaModelo{







public function agregar_respuesta_controlador(){
	$dni=mainModel::limpiar_cadena($_POST['dni-reg']);
	$nombre=mainModel::limpiar_cadena($_POST['nombre-reg']);
	$apellido=mainModel::limpiar_cadena($_POST['apellido-reg']);
		$fechaActual=date("Y-m-d");
			$yearActual=date("Y");
			$horaActual=date("h:i:s a");



		$consulta1=mainModel::ejecutar_consulta_simple("SELECT id_respuestas FROM respuestas WHERE id_novedades='$dni'");
		if($consulta1->rowCount()==0){



$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
		"Fecha"=>$fechaActual,
						"HoraInicio"=>$horaActual,
						"Year"=>$yearActual
	];
if(respuestaModelo::agregar_respuesta_modelo($dataAD)){


	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
	
		$alerta=[
			"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}		


}else{

			$alerta=[
		"Alerta"=>"simple",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"La respuetsa no es posible modificarla",
		"Tipo"=>"error"
		];


		}
	
	return mainModel::sweet_alert($alerta);
}




public function datos_respuesta_controlador($tipo,$codigo){
$codigo=mainModel::decryption($codigo);
$tipo=mainModel::limpiar_cadena($tipo);

return respuestaModelo::datos_respuesta_modelo($tipo,$codigo);
}






public function actualizar_respuesta_controlador(){

$dni=mainModel::limpiar_cadena($_POST['dni-up']);
$nombre=mainModel::limpiar_cadena($_POST['nombre-up']);
$apellido=mainModel::limpiar_cadena($_POST['apellido-up']);
	$fechaActual=date("Y-m-d");
			$yearActual=date("Y");
			$horaActual=date("h:i:s a");


$query1=mainModel::ejecutar_consulta_simple("SELECT * FROM respuestas WHERE id_respuestas='$dni'");
$DatosPropietario=$query1->fetch();
$dataAD=[
	"DNI"=>$dni,
	"Nombre"=>$nombre,
	"Apellido"=>$apellido,
		"Fecha"=>$fechaActual,
						"HoraInicio"=>$horaActual,
						"Year"=>$yearActual
	];
if(respuestaModelo::actualizar_respuesta_modelo($dataAD)){
	$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Felicidades",
		"Texto"=>"los datos fueron actualizados exitosamente",
		"Tipo"=>"success"
		];	
}else{
		$alerta=[
			"Alerta"=>"recargar",
		"Titulo"=>"Ocurrio un error inesperado",
		"Texto"=>"No hemos podido actualizar los datos intente nuevamente",
		"Tipo"=>"error"
		];	
}
return mainModel::sweet_alert($alerta);
}


}