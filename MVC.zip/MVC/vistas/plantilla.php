<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo COMPANY; ?></title>
    <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/bootstrap.min.css">
       <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/material-design-iconic-font.min.css">
      <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/bootstrap-material-design.min.css">
      
  <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/estiloso.css">
  <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/sweetalert2.css">
      <link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/icon/style.css">
           
      


    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
  <?php include "./vistas/modulos/script.php"; ?>
</head>
<body>

  


     <?php
       $peticionAjax=false;
    require_once "./controladores/vistasControlador.php";
    $vt = new vistasControlador();
    $vistasR=$vt->obtener_vistas_controlador();
    if($vistasR=="login" || $vistasR=="404"):
      if($vistasR=="login"){
        require_once "./vistas/contenidos/login-view.php";
      }else{
        require_once "./vistas/contenidos/404-view.php";
      }
  else:
    session_start(['name'=>'AMBAR']);
    require_once "./controladores/loginControlador.php";
    $lc = new loginControlador();
    if(!isset($_SESSION['token_ambar']) || !isset($_SESSION['usuario_ambar'])){
      echo $lc->forzar_cierre_sesion_controlador();

    }
  

  ?>

      
      
      
   <header><span class="lnr lnr-menu show"></span></header>
     <main>
   <?php include "vistas/modulos/navlateral.php"; 

  

 

        
   require_once $vistasR; ?>
       
    </main>
  <?php 

  include "./vistas/modulos/script.php";
  include "./vistas/modulos/logoutScript.php";

    ?>
<?php endif; ?>

</body>
</html>