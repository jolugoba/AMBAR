   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
       <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>admin" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Administradores" ></a>
                     <a href="<?php echo SERVERURL; ?>prop" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Propietarios" ></a>
             </div>
              <div class="container-fluid">
      <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>admin" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO ADMINISTRADOR
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>adminlist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE ADMINISTRADORES
            </a>
          </li>
          
      </ul>
    </div>
  
      <div class="panel panel-success">
         <div class="panel-body">

           <form action="<?php echo SERVERURL; ?>ajax/administradorAjax.php" method="POST" data-form="save" class="formulario" name="formulario_registro"  autocomplete="off" enctype="multipart/form-data"> 

   
    

     <div class="input-group label-floating">
               <div class="input-group"><i class="zmdi zmdi-account-circle">

            <input pattern="[0-9-]{1,30}" class="form-control" type="text" name="dni-reg" required="" maxlength="30" id="cedula">
            <label class="label" for="cedula">Cedula:</label></i> 
                    </div>
               
  </div>



                <div class="col-xs-12 col-sm-6">

                <div class="input-group label-floating">
                
          <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" class="form-control" type="text" name="nombre-reg" required="" maxlength="30" id="nombre">
            <label class="label" for="nombre">Nombre:</label></i> 
          
  </div>

               </div>     
  </div>



          <div class="col-xs-12 col-sm-6">
                    <div class="input-group label-floating">


              <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" class="form-control" type="text" name="apellido-reg" required="" maxlength="30" id="apellido">
            <label class="label" for="apellido">Apellido:</label></i> 
          </div>

  </div>
                </div>

 
          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[0-9+]{1,15}" class="form-control" type="text" name="telefono-reg" maxlength="15" id="telefono">
            <label class="label" for="telefono">Telefono:</label></i> 
          </div>
  </div>
                </div>
 

    <div class="col-xs-12 col-sm-6">
                    <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
                   
          <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="text" name="especialidad-reg"  maxlength="15" id="especialidad">
                     <label class="label" for="especialidad">Especialidad:</label></i> 
                </div>
                 </div>
                </div>
 


    <div class="input-group"><i class="zmdi zmdi-account-circle">
                   
          <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="text" name="usuario-reg"  maxlength="15" id="usuario">
                     <label class="label" for="usuario">Usuario:</label></i> 
                </div>
 

        <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input class="form-control" type="password" name="password1-reg" required="" maxlength="70" id="pass">
            <label class="label" for="pass">Contraseña:</label></i> 
          </div>
          </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input class="form-control" type="password" name="password2-reg" required="" maxlength="70" id="pass2">
            <label class="label" for="pass2">Repetir Contraseña:</label></i> 
          </div>
</div>
                </div>
                       <div class="input-group label-floating">
              <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input class="form-control" type="email" name="email-reg" maxlength="50" id="correo">
            <label class="label" for="correo">Correo:</label></i> 
              </div>     

   </div>     



         <div class="input-group radio"><i class="zmdi zmdi-account-circle">
            <input type="radio" name="optionsGenero" id="hombre" value="Hombre">
            <label for="hombre">Hombre</label></i> 
            <i class="zmdi zmdi-account-circle">
            <input type="radio" name="optionsGenero" id="mujer" value="Mujer">
            <label for="mujer">Mujer</label></i> 
          </div>

    <div class="input-group checkbox"><i class="zmdi zmdi-account-circle">
            <input type="checkbox" name="optionsPrivilegio" id="permisos"  value="<?php echo $lc->encryption(1); ?>">
            <label for="permisos">Conceder permisos de administrador</label></i> 
          </div>
          <input type="submit" id="btn-submit" value="Crear Usuario">
          <div class="RespuestaAjax"></div>
      </form>
</div>
    </div>
  
    </div>
  </div>
  