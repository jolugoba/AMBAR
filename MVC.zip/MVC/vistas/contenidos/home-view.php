   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
    


   <div class="contenedor-formulario">
           <div class="input-group">
             <input type="submit" id="btn-submit" value="Inicio">
             </div>
              <div class="container-fluid">
			<div class="page-header">
			  <h1 class="text-titles">Sistema de información 
			  	<small>AMBAR</small></h1>
			</div>
		</div>
		<div class="full-box text-center" style="padding: 30px 10px;">

            <?php 
            require "./controladores/administradorControlador.php";
            $IAdmin= new administradorControlador();
            $CAdmin= $IAdmin->datos_administrador_controlador("Conteo",0);

             ?>
			<article class="full-box tile">
				<div class="full-box tile-title text-center text-titles text-uppercase">
					Usuarios Administradores
				</div>
				<div class="full-box tile-icon text-center">
					<i class="zmdi zmdi-account"></i>
				</div>
				<div class="full-box tile-number text-titles">
					<p class="full-box"><?php echo $CAdmin->rowCount(); ?></p>
					<small>Registrados</small>
				</div>
			</article>
			
		</div>
		 


		</div>
		
		</div>