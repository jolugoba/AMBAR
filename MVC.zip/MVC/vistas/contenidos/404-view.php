
      <p class="text-center"><i class="zmdi zmdi-bug zmdi-hc-5x"></i></p>
          <div class="contenedor-formulario">
            
      <form action="index.php" class="formulario" name="formulario_registro" method="get">

           
           <div class="input-group">
             <input type="submit" id="btn-submit" value="Error 404 - Pagina no encontrada">
                            </div>
                      
       
      </form>





</div>
