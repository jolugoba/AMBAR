
       
       <div class="contenedor-formulario">
           <div class="input-group">
             <input type="submit" id="btn-submit" value="Modificar Datos Personales">
             </div>

<div class="container-fluid">
	<div class="wrap">

	<?php 
	$datos=explode("/", $_GET['views']);
	if($datos[1]=="user"):
		
   
        
      if($_SESSION['tipo_ambar']!="Propietario"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Propietario"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
    
    <?php 
   require_once "./controladores/propietarioControlador.php";
   $classAdmin= new propietarioControlador();
   $filesA=$classAdmin->datos_propietario_controlador("Unico",$datos[2]);

   if($filesA->rowCount()=='1'){

$campos=$filesA->fetch();

if($campos['CuentaCodigo']!=$_SESSION['codigo_cuenta_ambar']):
	if($_SESSION['privilegio_ambar']<1 || $_SESSION['privilegio_ambar']>2){
		echo $lc->forzar_cierre_sesion_controlador();

	}

endif;
?>
<div class="panel panel-success">
				<div class="panel-heading">
					<h3 class="panel-title"><i class="zmdi zmdi-refresh"></i> &nbsp; DATOS PERSONALES DE LA CUENTA</h3>
				</div>
				<div class="panel-body">
					<form action="<?php echo SERVERURL; ?>ajax/propietarioAjax.php" method="POST" data-form="update" class="formulario"  name="formulario_registro" autocomplete="off" enctype="multipart/form-data"> 
						<input type="hidden" name="cuenta-up" value="<?php echo $datos[2]; ?>">
				    	<fieldset>
				    		<legend><i class="zmdi zmdi-account-box"></i> &nbsp; Información personal de la cuenta <?php echo $campos['CuentaCodigo']; ?></legend>
				    



				    				





<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
										  
								    		



								    		<input pattern="[0-9-]{1,30}" class="form-control" type="text" name="dni-up" required="" maxlength="30" value="<?php echo $campos['PropietarioDNI']; ?>" id="cedula">									  	<label class="label" for="cedula" >DNI/CEDULA *</label></i>	
	
										</div>
	</div>
				    			</div>
				    			
</fieldset>

<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">

								    		
								    		<input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" class="form-control" type="text" name="nombre-up" required="" maxlength="30" value="<?php echo $campos['PropietarioNombre']; ?>">
										  	<label class="label">Nombres *</label></i>	
										  	
										</div>
				    				</div>
				    				</div>
</fieldset>

<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
										  	
										  	<input pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{1,30}" class="form-control" type="text" name="apellido-up" required="" maxlength="30" value="<?php echo $campos['PropietarioApellido']; ?>">
										  	<label class="label">Apellidos *</label></i>	
										</div>
				    				</div>
				    					</div>
</fieldset>


<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
										  	
										  	<input pattern="[0-9+]{1,15}" class="form-control" type="text" name="telefono-up" maxlength="15" value="<?php echo $campos['PropietarioTelefono']; ?>">
										  	<label class="label">Teléfono</label></i>	
										</div>
				    				</div>
				    					</div>

</fieldset>
<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group">
										  	
										  	<input pattern="[0-9+]{1,15}" class="form-control" type="hidden" name="ocupacion-up" maxlength="15" value="<?php echo $campos['PropietarioOcupacion']; ?>">
										 
										</div>
				    				</div>
				    					</div>

</fieldset>

<fieldset>

		    				          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group">
									  	
										  	<input type="hidden"  name="especialidad-up" class="form-control" rows="2" maxlength="100" value="<?php echo $campos['PropietarioDireccion']; ?>"></imput>
										 
										</div>
										</div>
				    				</div>
				    		

</fieldset>


				    	</fieldset>
					    <p class="text-center" style="margin-top: 20px;">
					    	<button type="submit" class="btn btn-success btn-raised btn-sm"><i class="zmdi zmdi-refresh"></i> Actualizar</button>
					    </p>
					     <div class="RespuestaAjax"></div>
				    </form>
				</div>
			</div>
<?php

   }else{
   	?>

	 <h4>Lo sentimos</h4>
	 <p>No podemos  mostrar la informacion</p>
   	<?php

   }

	elseif($datos[1]=="user"):
		echo "usuario";
	else:



	

	 ?>

	 <h4>Lo sentimos</h4>
	 <p>No podemos  mostrar la informacion</p>
	 <?php endif; ?>
			
		</div>
		</div>

