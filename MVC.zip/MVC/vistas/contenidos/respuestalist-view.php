   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
  
   
        <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>novedades/0" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Novedades" ></a>
                                  </div>
              <div class="container-fluid">
      <ul class="breadcrumb breadcrumb-tabs">
       
          <li>
            
            <a href="<?php echo SERVERURL; ?>respuestalist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE NOVEDADES
            </a>
          </li>
              </ul>
    </div>
  

<?php 
require_once "./controladores/novedadesControlador.php";
$insAdmin= new novedadesControlador();
 ?>
       
       <div class="container-fluid">
      <div class="panel panel-success">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE NOVEDADES</h3>
        </div>
        <div class="panel-body">
       


<?php 
$pagina = explode("/", $_GET['views']);
$pa=$insAdmin->paginador_novedades_controlador($pagina[1],8,$_SESSION['privilegio_ambar'],$_SESSION['codigo_cuenta_ambar']);
echo $pa;
 ?>
       
        </div>
      </div>
    </div>

    </div>