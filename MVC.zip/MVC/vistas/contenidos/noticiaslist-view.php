    
   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
      }
    ?>
  
   
        <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>noticias/0" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Noticias" ></a>
                                  </div>
              <div class="container-fluid">


      <ul class="breadcrumb breadcrumb-tabs">
        <?php if($_SESSION['tipo_ambar']=="Administrador"): ?>
          <li>
            <a href="<?php echo SERVERURL; ?>noticias" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; CREAR NOTICIAS
            </a>
          </li>
          <?php endif; ?>
          <li>
           <a href="<?php echo SERVERURL; ?>noticiaslist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE NOTICIAS
            </a>
          </li>
              </ul>
    </div>
  

<?php 
require_once "./controladores/noticiasControlador.php";
$insAdmin= new noticiasControlador();
 ?>
       
       <div class="container-fluid">
      <div class="panel panel-success">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE NOTICIAS</h3>
        </div>
        <div class="panel-body">
       


<?php 
$pagina = explode("/", $_GET['views']);
$pa=$insAdmin->paginador_noticias_controlador($pagina[1],8,$_SESSION['privilegio_ambar'],$_SESSION['codigo_cuenta_ambar']);
echo $pa;
 ?>
       
        </div>
      </div>
    </div>

    </div>