
   
           <div class="contenedor-formulario">
               <div class="input-group">
             <input type="submit" id="btn-submit" value="Actualizar Usuario">
             </div>
    <div class="wrap">
      <form action="" class="formulario" name="formulario_registro" method="get">
       
          <div class="input-group">
            <input type="text" id="nombre" name="nombre">
            <label class="label" for="nombre">Nombre:</label>
          </div>
           <div class="input-group">
            <input type="text" id="cedula" name="cedula">
            <label class="label" for="cedula">Cedula:</label>
          </div>
          <div class="input-group">
            <input type="email" id="correo" name="correo">
            <label class="label" for="correo">Correo:</label>
          </div>
            <div class="input-group">
            <input type="text" id="telefono" name="telefono">
            <label class="label" for="telefono">Telefono:</label>
          </div>
          <div class="input-group">
            <input type="password" id="pass" name="pass">
            <label class="label" for="pass">Contraseña:</label>
          </div>
          <div class="input-group">
            <input type="password" id="pass2" name="pass2">
            <label class="label" for="pass2">Repetir Contraseña:</label>
          </div>
          <div class="input-group radio">
            <input type="radio" name="sexo" id="hombre" value="Hombre">
            <label for="hombre">Hombre</label>
            <input type="radio" name="sexo" id="mujer" value="Mujer">
            <label for="mujer">Mujer</label>
          </div>
          <div class="input-group checkbox">
            <input type="checkbox" name="permisos" id="permisos" value="true">
            <label for="permisos">Conceder permisos de administrador</label>
          </div>
            
          <input type="submit" id="btn-submit" value="Actualizar Usuario">
       
      </form>
    </div>
  </div>
    