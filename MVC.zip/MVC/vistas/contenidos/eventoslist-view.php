    
   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
      }
    ?>
  
   
        <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>eventos/0" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Eventos" ></a>
                                  </div>
              <div class="container-fluid">
      <ul class="breadcrumb breadcrumb-tabs">
            <?php if($_SESSION['tipo_ambar']=="Administrador"): ?>
          <li>
            <a href="<?php echo SERVERURL; ?>noticias" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; CREAR EVENTOS
            </a>
          </li>
          <?php endif; ?>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>eventoslist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE EVENTOS
            </a>
          </li>
              </ul>
    </div>
  

<?php 
require_once "./controladores/eventosControlador.php";
$insAdmin= new eventosControlador();
 ?>
       
       <div class="container-fluid">
      <div class="panel panel-success">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE EVENTOS</h3>
        </div>
        <div class="panel-body">
       


<?php 
$pagina = explode("/", $_GET['views']);
$pa=$insAdmin->paginador_eventos_controlador($pagina[1],8,$_SESSION['privilegio_ambar'],$_SESSION['codigo_cuenta_ambar']);
echo $pa;
 ?>
       
        </div>
      </div>
    </div>

    </div>