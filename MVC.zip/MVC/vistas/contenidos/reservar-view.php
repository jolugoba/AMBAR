
         <div class="contenedor-formulario">
       <div class="input-group">
             <input type="submit" id="btn-submit" value="Salon Comunal Primero">
              </div>
    <div class="wrap">
      <form action="reservar.html" class="formulario" name="formulario_registro" method="get">
       
          
                
          <div class="input-group">
            <input type="text" id="nombre" name="nombre">
            <label class="label" for="nombre">Nombre del Evento:</label>
          </div>

            <div class="input-group">
          <input  type="date" id="date">  
          <label class="label" for="date">Fecha para Reservar:</label>        
          </div>

         <div class="input-group">
            <input type="text" id="responsable" name="responsable">
            <label class="label" for="responsable">Nombre del responsable:</label>
          </div>
            
            <div class="input-group">
            <input type="text" id="telefono" name="telefono">
            <label class="label" for="telefono">Numero del responsable:</label>
          </div>

          <input type="submit" id="btn-submit" value="Reservar">


       
      </form>
    </div>
  </div>