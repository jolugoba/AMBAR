

       
       <div class="contenedor-formulario">
           <div class="input-group">
             <input type="submit" id="btn-submit" value="Respuesta Novedades">
             </div>

<div class="container-fluid">
	<div class="wrap">

	<?php 
	$datos=explode("/", $_GET['views']);
	if($datos[1]=="user"):
		
   
        
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
    
    <?php 
   require_once "./controladores/propietarioControlador.php";
   $classAdmin= new propietarioControlador();
   $filesA=$classAdmin->datos_respuesta_controlador("Unico",$datos[2]);
 require_once "./controladores/respuestaControlador.php";
   $classAdmins= new respuestaControlador();
   $filesAs=$classAdmins->datos_respuesta_controlador("Unico",$datos[2]);
   if($filesA->rowCount()=='1' || $filesAs->rowCount()=='1'){

$campos=$filesA->fetch();
$camposs=$filesAs->fetch();





?>









<div class="panel panel-success">
				<div class="panel-heading">
					<h3 class="panel-title"><i class="zmdi zmdi-refresh"></i> &nbsp;DATOS DE LA NOVEDAD</h3>
				</div>
				<div class="panel-body">
						
						<form  data-form="update" class="formulario"  name="formulario_registro" autocomplete="off" enctype="multipart/form-data"> 

						<input type="hidden" name="cuenta-up" value="<?php echo $datos[2]; ?>">
				    	<fieldset>
				    		<legend><i class="zmdi zmdi-account-box"></i> &nbsp; Novedad # <?php echo $campos['id_novedades'];?> de la Torre <?php echo $campos['torre'];?> Apartamento  <?php echo  $campos['numero']; ?></legend>
				    



				    				





<fieldset>

		    				          <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
										  
								    		



								    		<input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="text" name="dni-up" required="" maxlength="30" value="<?php echo $campos['asunto_novedades']; ?>" id="cedula">									  	<label class="label" for="cedula" >Asunto de la Novedad *</label></i>	
	
										</div>
	</div>
				    			</div>
				    			
</fieldset>

<fieldset>

		    				          <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">

								    		<textarea pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="textarea" name="nombre-up" required="" maxlength="4000" id="nombre" style="margin: 8px;  height: 388px;"><?php echo $campos['asunto_novedades']; ?></textarea>


								    	
										  	<label class="label">Descripcion de la Novedad *</label></i>	
										  	
										</div>
				    				</div>
				    				</div>
</fieldset>


</form>


<?php if ($campos['respuesta']=="No"): ?> 
		<form action="<?php echo SERVERURL; ?>ajax/respuestaAjax.php" method="POST" data-form="update" class="formulario"  name="formulario_registro" autocomplete="off" enctype="multipart/form-data"> 
<legend><i class="zmdi zmdi-account-box"></i> &nbsp; Respuesta de la Novedad # <?php echo $campos['id_novedades'];?> de la Torre <?php echo $campos['torre'];?> Apartamento  <?php echo  $campos['numero']; ?></legend>

     <div class="input-group label-floating">
               <div class="input-group">

            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="hidden" name="dni-reg" required="" maxlength="30" id="cedula" value="<?php echo $campos['id_novedades']; ?>">
            
                    </div>
               
  </div>
      <fieldset>


     <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="text" name="nombre-reg" required="" maxlength="30" id="nombre">
            <label class="label" for="nombre">Ingrese el Asunto de la Respuesta:</label></i> 
          
  </div>

               </div>     
  </div>

</fieldset>

         <fieldset>

		    				          <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">

								    		<textarea pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="textarea" name="apellido-reg" required="" maxlength="4000" id="apellido" style="margin: 8px;  height: 388px;"></textarea>


								    	
										  	<label class="label">Ingrese la Descripcion de la Respuesta *</label></i>	
										  	
										</div>
				    				</div>
				    				</div>
</fieldset>

 
          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group">
            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" pattern="[0-9-]{1,30}" class="form-control" type="hidden" name="telefono-reg" maxlength="15" id="telefono">
            
          </div>
  </div>
                </div>
  
  

    <div class="input-group">
                   
          <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="hidden" name="usuario-reg"  maxlength="15" id="usuario">
                  
                </div>
 

        <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password1-reg" required="" maxlength="70" id="pass">
            
          </div>
          </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password2-reg" required="" maxlength="70" id="pass2">
            
          </div>
</div>
                </div>
                       <div class="input-group label-floating">
              <div class="input-group">
            <input class="form-control" type="hidden" name="email-reg" maxlength="50" id="correo">
            
              </div>     

   </div>     



         <div class="input-group radio">
            <input type="hidden" name="optionsGenero" id="hombre" value="Hombre">
            
          
            <input type="hidden" name="optionsGenero" id="mujer" value="Mujer">
            
          </div>

    <div class="input-group checkbox">
            <input type="hidden" name="optionsPrivilegio" id="permisos"  value="">
            
          </div>
          <input type="submit" id="btn-submit" value="Crear Respuesta">
          <div class="RespuestaAjax"></div>
      </form>


				    
				    



			
		</div>
			</div>


<?php endif; ?>



<?php   
if ($campos['respuesta']=="Si"): ?> 


		<form action="<?php echo SERVERURL; ?>ajax/respuestaAjax.php" method="POST" data-form="update" class="formulario"  name="formulario_registro" autocomplete="off" enctype="multipart/form-data"> 
<legend><i class="zmdi zmdi-account-box"></i> &nbsp; Respuesta de la Novedad # <?php echo $campos['id_novedades'];?> de la Torre <?php echo $campos['torre'];?> Apartamento  <?php echo  $campos['numero']; ?></legend>

     <div class="input-group label-floating">
               <div class="input-group">

            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="hidden" name="dni-up" required="" maxlength="30" id="cedula" value="<?php echo $camposs['id_respuestas']; ?>">
            
                    </div>
               
  </div>
         <fieldset>


     <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="text" name="nombre-up" required="" maxlength="30" id="nombre" value="<?php echo $camposs['asunto_respuestas']; ?>">
            <label class="label" for="nombre">Asunto de la Respuesta:</label></i> 
          
  </div>

               </div>     
  </div>

</fieldset>

         <fieldset>

		    				          <div class="col-xs-12 col-sm-12">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">

								    		<textarea pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="textarea" name="apellido-up" required="" maxlength="4000" id="apellido" style="margin: 8px;  height: 388px;"><?php echo $camposs['descripcion_respuestas']; ?></textarea>


								    	
										  	<label class="label">Descripcion de la Respuesta:</label></i>	
										  	
										</div>
				    				</div>
				    				</div>
</fieldset>

 
          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group">
            <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" pattern="[0-9-]{1,30}" class="form-control" type="hidden" name="telefono-reg" maxlength="15" id="telefono">
            
          </div>
  </div>
                </div>
  
  

    <div class="input-group">
                   
          <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="hidden" name="usuario-reg"  maxlength="15" id="usuario">
                  
                </div>
 

        <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password1-reg" required="" maxlength="70" id="pass">
            
          </div>
          </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password2-reg" required="" maxlength="70" id="pass2">
            
          </div>
</div>
                </div>
                       <div class="input-group label-floating">
              <div class="input-group">
            <input class="form-control" type="hidden" name="email-reg" maxlength="50" id="correo">
            
              </div>     

   </div>     



         <div class="input-group radio">
            <input type="hidden" name="optionsGenero" id="hombre" value="Hombre">
            
          
            <input type="hidden" name="optionsGenero" id="mujer" value="Mujer">
            
          </div>

    <div class="input-group checkbox">
            <input type="hidden" name="optionsPrivilegio" id="permisos"  value="">
            
          </div>
          <input type="submit" id="btn-submit" value="Modificar Respuesta">
          <div class="RespuestaAjax"></div>
      </form>


				    
				    

		</div>
			</div>


<?php endif; ?>




  		
		
<?php

   }else{

   	?>

	 <h4>Lo sentimos</h4>
	 <p>No podemos  mostrar la informacion</p>
   	<?php

   }

	elseif($datos[1]=="user"):
		echo "usuario";
	else:



	

	 ?>

	 <h4>Lo sentimos</h4>
	 <p>No podemos  mostrar la informacion</p>
	 <?php endif; ?>
			
		</div>
		</div>

