   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>

<div class="contenedor-formulario">
       <div class="input-group">
             <input type="submit" id="btn-submit" value="Usuarios del Sistema">
                   </div>
    <div class="wrap">
       
             
     

           
             <div class="input-group">
              <a href="<?php echo SERVERURL; ?>admin" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Administrador" ></a>
                     <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>admin" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO ADMINISTRADOR
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>adminlist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE ADMINISTRADORES
            </a>
          </li>
        
      </ul>     
              </div>  

             <div class="input-group">
              <a href="<?php echo SERVERURL; ?>prop" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Propietarios" ></a>
                            <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>prop" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO PROPIETARIO
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>proplist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE PROPIETARIOS
            </a>
          </li>
        
      </ul>
              </div>  
       
 
    </div>
