 <?php 
 
    



  
         
  
    

        
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>


 <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>apartamentos/0" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Torres" ></a>
                     <a href="<?php echo SERVERURL; ?>apartamentosearch" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Apartamentos" ></a>
             </div>
              <div class="container-fluid">
       
             <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>apartamentomod" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; CREAR APARTAMENTOS
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>apartamentos/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE APARTAMENTOS
            </a>
          </li>
      
      </ul>
      
<?php 
require_once "./controladores/apartamentosControlador.php";
$insAdmin= new apartamentosControlador();

 ?>
       
       <div class="container-fluid">
      <div class="panel panel-success">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTADO DE APARTAMENTOS DE LA TORRE # <?php echo $_POST["post"]; ?> </h3>
        </div>
        <div class="panel-body">
       



<?php 

$posto=$_POST["post"];
$pagina = explode("/", $_GET['views']);
$pa=$insAdmin->paginador_apartamento_controlador($pagina[1],8,$_SESSION['privilegio_ambar'],$_SESSION['codigo_cuenta_ambar'],$posto);
echo $pa;
die();
 ?>
</form>
              </div>  

        </div>
        </div>
       

        