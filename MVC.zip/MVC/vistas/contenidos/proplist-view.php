   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
  <div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>admin" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Administradores" ></a>
                     <a href="<?php echo SERVERURL; ?>prop" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Usuarios Propietarios" ></a>
             </div>
              <div class="container-fluid">
      <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>prop" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; NUEVO PROPIETARIO
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>proplist/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE PROPIETARIOS
            </a>
          </li>
        
      </ul>
    </div>  

<?php 
require_once "./controladores/propietarioControlador.php";
$insAdmin= new propietarioControlador();
 ?>
       
       <div class="container-fluid">
      <div class="panel panel-success">
        <div class="panel-heading">
          <h3 class="panel-title"><i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTA DE PROPIETARIOS</h3>
        </div>
        <div class="panel-body">
       


<?php 
$pagina = explode("/", $_GET['views']);
$pa=$insAdmin->paginador_propietario_controlador($pagina[1],8,$_SESSION['privilegio_ambar'],$_SESSION['codigo_cuenta_ambar']);
echo $pa;
 ?>
       
        </div>
      </div>
    </div>

    </div>