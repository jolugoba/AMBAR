   <?php 
      if($_SESSION['tipo_ambar']!="Propietario"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Propietario"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
   
       <div class="contenedor-formulario">
           <div class="input-group">
             <input type="submit" id="btn-submit" value="Inicio">
             </div>
   <div class="container-fluid">
      <div class="page-header">
        <h1 class="text-titles"><i class="zmdi zmdi-book-image zmdi-hc-fw"></i> BIENVENIDO</h1>
      </div>
    
        </div>
      </div>
    </div>
  </div>
   