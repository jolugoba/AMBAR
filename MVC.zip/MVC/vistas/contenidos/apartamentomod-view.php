   <?php 
      if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
         if($_SESSION['tipo_ambar']!="Administrador"){

        echo $lc->forzar_cierre_sesion_controlador();
      }
      }
    ?>
    
<div class="contenedor-formulario">
           <div class="input-group">
                  <a href="<?php echo SERVERURL; ?>apartamentos/0" class="btn btn-info">
             <input type="submit" id="btn-submit" value="Torres" ></a>
                     
             </div>
              <div class="container-fluid">
      <ul class="breadcrumb breadcrumb-tabs">
          <li>
            <a href="<?php echo SERVERURL; ?>apartamentomod" class="btn btn-info">
              <i class="zmdi zmdi-plus"></i> &nbsp; CREAR APARTAMENTOS
            </a>
          </li>
          <li>
            <a 
            <a href="<?php echo SERVERURL; ?>apartamentos/0" class="btn btn-success">
              <i class="zmdi zmdi-format-list-bulleted"></i> &nbsp; LISTAR DE APARTAMENTOS
            </a>
          </li>
      
      </ul>
    </div>
  
      <div class="panel panel-success">
         <div class="panel-body">

           <form action="<?php echo SERVERURL; ?>ajax/propietarioaAjax.php" method="POST" data-form="save" class="formulario" name="formulario_registro"  autocomplete="off" enctype="multipart/form-data"> 

   
    

     <div class="input-group label-floating">
               <div class="input-group"><i class="zmdi zmdi-account-circle">

            <input pattern="[0-9-]{1,30}" class="form-control" type="text" name="dni-reg" required="" maxlength="30" id="cedula">
            <label class="label" for="cedula">Torre:</label></i> 
                    </div>
               
  </div>



                <div class="col-xs-12 col-sm-6">

                <div class="input-group label-floating">
                
          <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[0-9-]{1,30}" class="form-control" type="text" name="nombre-reg" required="" maxlength="30" id="nombre">
            <label class="label" for="nombre">Numero Apartamento:</label></i> 
          
  </div>

               </div>     
  </div>



          <div class="col-xs-12 col-sm-6">
                    <div class="input-group label-floating">


              <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[0-9-]{1,30}" class="form-control" type="text" name="apellido-reg" required="" maxlength="30" id="apellido">
            <label class="label" for="apellido">Area Mts2:</label></i> 
          </div>

  </div>
                </div>

 
          <div class="col-xs-12 col-sm-6">
                      <div class="input-group label-floating">
    <div class="input-group"><i class="zmdi zmdi-account-circle">
            <input pattern="[0-9-]{1,30}" class="form-control" type="text" name="telefono-reg" maxlength="15" id="telefono">
            <label class="label" for="telefono">Parqueadero:</label></i> 
          </div>
  </div>
                </div>
  
  

    <div class="input-group">
                   
          <input pattern="[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ]{1,15}" class="form-control" type="hidden" name="usuario-reg"  maxlength="15" id="usuario">
                  
                </div>
 

        <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password1-reg" required="" maxlength="70" id="pass">
            
          </div>
          </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                   <div class="input-group label-floating">
          <div class="input-group">
            <input class="form-control" type="hidden" name="password2-reg" required="" maxlength="70" id="pass2">
            
          </div>
</div>
                </div>
                       <div class="input-group label-floating">
              <div class="input-group">
            <input class="form-control" type="hidden" name="email-reg" maxlength="50" id="correo">
            
              </div>     

   </div>     



         <div class="input-group radio">
            <input type="hidden" name="optionsGenero" id="hombre" value="Hombre">
            
          
            <input type="hidden" name="optionsGenero" id="mujer" value="Mujer">
            
          </div>

    <div class="input-group checkbox">
            <input type="hidden" name="optionsPrivilegio" id="permisos"  value="">
            
          </div>
          <input type="submit" id="btn-submit" value="Crear Usuario">
          <div class="RespuestaAjax"></div>
      </form>
</div>
    </div>
  
    </div>
  </div>
  