 <div class="contenedor-formulario">
   <div class="input-group">
             <input type="submit" id="btn-submit" value="cartelera">
             </div>
 <div class="wrap">

      <form action="cartelera.html" class="formulario" name="formulario_registro" method="get">
      
        
          <div class="input-group">
            <input type="text" id="asunto" name="asunto">
            <label class="label" for="asunto">Asunto:</label>
          </div>
          
          
            <div class="input-group">
            <input type="text" id="descripcion" name="descripcion">
            <label class="label" for="descripcion">Descripción:</label>
          </div>
          
            
          <input type="submit" id="btn-submit" value="Crear Noticia">
      
      </form>
    </div>
  </div>