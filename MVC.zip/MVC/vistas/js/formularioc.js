// Recorrer los elementos y hacer que onchange ejecute una funcion para comprobar el valor de ese input
(function() {


}())