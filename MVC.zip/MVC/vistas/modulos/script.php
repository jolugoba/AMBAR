<script src="<?php echo SERVERURL; ?>vistas/js/formulario.js"></script>
    <script src="<?php echo SERVERURL; ?>vistas/js/jquery.js"></script>
    <script src="<?php echo SERVERURL; ?>vistas/js/script.js"></script>
    <script src="<?php echo SERVERURL; ?>vistas/js/formularioajax.js"></script>
     <script src="<?php echo SERVERURL; ?>vistas/js/sweetalert2.min.js"></script>
     <script src="<?php echo SERVERURL; ?>vistas/js/material.min.js"></script>
     <script src="<?php echo SERVERURL; ?>vistas/js/main.js"></script>
     <script src="<?php echo SERVERURL; ?>vistas/js/jquery.mCustomScrollbar.concat.min.js"></script>

