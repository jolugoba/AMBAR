

<?php 
if($_SESSION['tipo_ambar']!="Administrador"){

    echo $lc->redireccionar_usuario_controlador($_SESSION['tipo_ambar']);
}
?>
<div class="content-menu">
    <?php if($_SESSION['tipo_ambar']=="Administrador"): ?>
        <li><a href="<?php echo SERVERURL; ?>home"><span ><img src="<?php echo SERVERURL; ?>vistas/assets/avatars/<?php echo $_SESSION['foto_ambar'];?>  " alt="UserIcon"></span><h4 class="text8">Inicio</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>apartamentos/0"><span class="lnr lnr-apartment icon1"></span><h4 class="text1">Conjunto</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>usuarios"><span class="lnr lnr-users icon4"></span><h4 class="text4">Usuarios</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>respuestalist/0"><span class="lnr lnr-calendar-full icon6"></span><h4 class="text6">Novedades</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>noticias"><span class="lnr lnr-alarm icon2"></span><h4 class="text2">Noticias</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>eventos"><span class="lnr lnr-license icon9"></span><h4 class="text9">Eventos</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>informes"><span class="lnr lnr-file-add icon7"></span><h4 class="text7">Informes</h4></li></a>
        
    <?php endif; ?>

    <?php if($_SESSION['tipo_ambar']=="Propietario"): ?>

        <li><a href="<?php echo SERVERURL; ?>catalogo"><span ><img src="<?php echo SERVERURL; ?>vistas/assets/avatars/<?php echo $_SESSION['foto_ambar'];?>  " alt="UserIcon"></span><h4 class="text8">Inicio</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>noticiaslist/0"><span class="lnr lnr-alarm icon2"></span><h4 class="text2">Noticias</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>novedades"><span class="lnr lnr-calendar-full icon6"></span><h4 class="text6">Novedades</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>eventoslist/0"><span class="lnr lnr-license icon9"></span><h4 class="text9">Eventos</h4></li></a>
        <li><a href="<?php echo SERVERURL; ?>informeslist/0"><span class="lnr lnr-file-add icon7"></span><h4 class="text7">Informes</h4></li></a>
        
        
    <?php endif; ?>     
    <div class="full-box dashboard-sideBar-UserInfo">
      
        <?php 
        if($_SESSION['tipo_ambar']=="Administrador"){
            $tipo="admin";
        }else{
            $tipo="user";
            
        }
        ?>


        <?php if($_SESSION['tipo_ambar']=="Administrador"): ?>
            <ul class="full-box list-unstyled text-center">
                <li>
                    <a href="<?php echo SERVERURL; ?>mydata/<?php echo $tipo; ?>/<?php echo $lc->encryption($_SESSION['codigo_cuenta_ambar']); ?>/" title="Mis datos">
                        <i class="zmdi zmdi-account-circle"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo SERVERURL; ?>myaccount/<?php echo $tipo; ?>/<?php echo $lc->encryption($_SESSION['codigo_cuenta_ambar']); ?>/" title="Mi cuenta">
                        <i class="zmdi zmdi-settings"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo $lc->encryption($_SESSION['token_ambar']); ?>" title="Salir del sistema" class="btn-exit-system">
                        <i class="zmdi zmdi-power"></i>
                    </a>
                </li>
            </ul>
        <?php endif; ?>

        <?php if($_SESSION['tipo_ambar']=="Propietario"): ?>
            <ul class="full-box list-unstyled text-center">
                <li>
                    <a href="<?php echo SERVERURL; ?>mydatap/<?php echo $tipo; ?>/<?php echo $lc->encryption($_SESSION['codigo_cuenta_ambar']); ?>/" title="Mis datos">
                        <i class="zmdi zmdi-account-circle"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo SERVERURL; ?>myaccountp/<?php echo $tipo; ?>/<?php echo $lc->encryption($_SESSION['codigo_cuenta_ambar']); ?>/" title="Mi cuenta">
                        <i class="zmdi zmdi-settings"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo $lc->encryption($_SESSION['token_ambar']); ?>" title="Salir del sistema" class="btn-exit-system">
                        <i class="zmdi zmdi-power"></i>
                    </a>
                </li>
            </ul>

        <?php endif; ?> 
    </div>
</div>