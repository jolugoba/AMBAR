<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg']) || $_POST['dni-up']){
require_once "../controladores/respuestaControlador.php";
$insAdmin = new respuestaControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg']) && isset($_POST['apellido-reg']) ){
	echo $insAdmin->agregar_respuesta_controlador();

}


if(isset($_POST['dni-up']) && isset($_POST['nombre-up']) && isset($_POST['apellido-up'])){
echo $insAdmin->actualizar_respuesta_controlador();


}


}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}