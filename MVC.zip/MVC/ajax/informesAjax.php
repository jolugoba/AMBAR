<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg'])){
require_once "../controladores/informesControlador.php";
$insAdmin = new informesControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg'])){
	echo $insAdmin->agregar_informes_controlador();

}



if(isset($_POST['dni-up']) && isset($_POST['nombre-up']) && isset($_POST['apellido-up'])){
echo $insAdmin->actualizar_informes_controlador();


}


}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}