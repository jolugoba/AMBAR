<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg'])){
require_once "../controladores/propietarioaControlador.php";
$insAdmin = new propietarioaControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg']) && isset($_POST['apellido-reg']) && isset($_POST['telefono-reg'])){
	echo $insAdmin->agregar_propietarioa_controlador();

}

if(isset($_POST['codigo-del']) && isset($_POST['privilegio-propietario'])){
echo $insAdmin->eliminar_propietarioa_controlador();
}

if(isset($_POST['cuenta-up']) && isset($_POST['dni-up'])){
echo $insAdmin->actualizar_propietarioa_controlador();

}


}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}