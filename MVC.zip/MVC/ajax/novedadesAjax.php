<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg'])){
require_once "../controladores/novedadesControlador.php";
$insAdmin = new novedadesControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg'])){
	echo $insAdmin->agregar_novedades_controlador();

}




}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}