<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg'])){
require_once "../controladores/eventosControlador.php";
$insAdmin = new eventosControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg'])){
	echo $insAdmin->agregar_eventos_controlador();

}



if(isset($_POST['dni-up']) && isset($_POST['nombre-up']) && isset($_POST['apellido-up'])){
echo $insAdmin->actualizar_eventos_controlador();


}


}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}