<?php 
$peticionAjax=true;
require_once "../core/configGeneral.php";
if(isset($_POST['dni-reg']) || isset($_POST['codigo-del']) || isset($_POST['cuenta-up']) || isset($_POST['cuenta-upp']) || isset($_POST['ocupacion-up'])){
require_once "../controladores/propietarioControlador.php";
$insAdmin = new propietarioControlador();


if(isset($_POST['dni-reg']) && isset($_POST['nombre-reg']) && isset($_POST['apellido-reg']) && isset($_POST['usuario-reg'])){
	echo $insAdmin->agregar_propietario_controlador();

}

if(isset($_POST['codigo-del']) && isset($_POST['privilegio-propietario'])){
echo $insAdmin->eliminar_propietario_controlador();
}

if(isset($_POST['cuenta-up']) && isset($_POST['dni-up'])){
echo $insAdmin->actualizar_propietario_controlador();

}

if(isset($_POST['cuenta-up']) && isset($_POST['dni-up']) && isset($_POST['ocupacion-up'])){
echo $insAdmin->actualizar_propietario_apartamento_controlador();

}



if(isset($_POST['cuenta-upp']) && isset($_POST['dni-up'])){
echo $insAdmin->actualizar_apartamento_controlador();

}


}else{
	session_start(['name'=>'AMBAR']);
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/" </script>';
}